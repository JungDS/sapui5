# SAP Developer Learning Library v3

- 생성일: 2026-05-27
- 배포자: 정훈영
- 문서 수: 34개

## 사용 방법
압축을 해제한 뒤 `index.html`을 브라우저에서 여세요.

## 구조
- `assets/common.css`: 공통 디자인
- `assets/common.js`: 용어 팝업, 코드 복사, 실습 로직
- `v3/*.html`: v3 학습 문서
- `data/document-catalog.json`: 문서 목록


## 문체 기준
- 개념 설명: 평서형
- 실습/체크리스트: 지시형
- 강사용 메모: 존칭형
- 배포자: 정훈영
