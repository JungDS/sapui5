// SAP Learning Library v3 Common Logic
(function () {
  "use strict";

  const termDefinitions = {
    "SAPUI5": "SAP에서 제공하는 웹 UI 프레임워크입니다. Fiori 스타일의 업무 화면을 만들 때 사용합니다.",
    "Model": "앱이 실제로 신뢰하는 데이터 저장소입니다. Input에 보이는 값이 곧바로 Model 값이라는 뜻은 아닙니다.",
    "Input": "사용자가 값을 입력하는 UI5 Control입니다. 입력값은 검증을 통과해야 Model에 반영됩니다.",
    "Binding": "Control 속성과 Model 경로를 연결하는 방식입니다. 예: Input.value와 view>/Age를 연결합니다.",
    "Binding Type": "입력값을 어떤 타입으로 해석할지 정하는 UI5 타입입니다. Integer, Decimal, Date 등이 대표적입니다.",
    "constraints": "값이 지켜야 하는 제약 조건입니다. minimum, maximum 같은 범위 조건이 여기에 해당합니다.",
    "Messaging": "UI5의 중앙 메시지 처리 모듈입니다. 최신 코드는 sap/ui/core/Messaging을 import해서 사용합니다.",
    "MessageModel": "현재 앱에 쌓인 Error, Warning, Information 메시지를 담는 모델입니다.",
    "Guard": "저장이나 서버 요청 전에 위험한 상태를 막는 방어 로직입니다.",
    "OData": "SAP 시스템과 프론트엔드가 데이터를 주고받을 때 자주 사용하는 표준 API 방식입니다.",
    "RAP": "RESTful ABAP Programming Model입니다. S/4HANA에서 비즈니스 객체와 OData 서비스를 만들 때 사용합니다.",
    "Controller": "화면에서 발생한 이벤트를 처리하는 JavaScript 파일입니다.",
    "Event Handler": "버튼 클릭이나 입력 변경처럼 사용자의 행동에 반응하는 함수입니다.",
    "this": "현재 Controller 인스턴스를 가리키는 JavaScript 키워드입니다. UI5 Controller에서 매우 자주 사용합니다.",
    "ATP": "Available-to-Promise의 약자입니다. 고객에게 약속할 수 있는 수량이나 납기를 확인하는 과정입니다.",
    "재고": "현재 창고나 플랜트에 존재하는 물리적 수량입니다.",
    "가용수량": "현재 재고에서 이미 예약되었거나 출고 예정인 수량을 고려해 실제로 약속 가능한 수량입니다.",
    "판매오더": "고객이 특정 상품을 특정 수량과 납기로 요청한 주문 문서입니다."
  };

  function ensureTermModal() {
    if (document.getElementById("termModal")) return;
    const modal = document.createElement("div");
    modal.className = "term-modal";
    modal.id = "termModal";
    modal.setAttribute("aria-hidden", "true");
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.innerHTML = `
      <div class="term-modal__backdrop" data-term-close="true"></div>
      <div class="term-modal__box" role="document">
        <button class="term-modal__close" type="button" data-term-close="true" aria-label="용어 설명 닫기">×</button>
        <div class="term-modal__eyebrow">초급자 용어 설명</div>
        <h2 class="term-modal__title" id="termModalTitle">용어</h2>
        <p class="term-modal__body" id="termModalBody">설명</p>
      </div>
    `;
    document.body.appendChild(modal);
  }

  function initTerms() {
    ensureTermModal();
    const modal = document.getElementById("termModal");
    const title = document.getElementById("termModalTitle");
    const body = document.getElementById("termModalBody");
    let lastFocus = null;

    function openTerm(term) {
      const text = termDefinitions[term] || "이 용어는 현재 문서의 맥락에서 다시 확인이 필요한 항목입니다.";
      lastFocus = document.activeElement;
      title.textContent = term;
      body.textContent = text;
      modal.classList.add("is-open");
      modal.setAttribute("aria-hidden", "false");
      const close = modal.querySelector(".term-modal__close");
      if (close) close.focus();
    }

    function closeTerm() {
      modal.classList.remove("is-open");
      modal.setAttribute("aria-hidden", "true");
      if (lastFocus && typeof lastFocus.focus === "function") lastFocus.focus();
    }

    document.addEventListener("click", function (event) {
      const term = event.target.closest("[data-term]");
      if (term) {
        event.preventDefault();
        openTerm(term.getAttribute("data-term"));
        return;
      }
      if (event.target.matches("[data-term-close]")) {
        closeTerm();
      }
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && modal.classList.contains("is-open")) closeTerm();
    });
  }

  function initCopyButtons() {
    document.querySelectorAll(".code-block").forEach(function (block, index) {
      const header = block.querySelector(".code-header");
      const code = block.querySelector("pre code");
      if (!header || !code || header.querySelector(".copy-btn")) return;
      const button = document.createElement("button");
      button.className = "copy-btn";
      button.type = "button";
      button.textContent = "복사";
      button.addEventListener("click", async function () {
        try {
          await navigator.clipboard.writeText(code.textContent);
          button.textContent = "복사됨";
          setTimeout(() => button.textContent = "복사", 1200);
        } catch (e) {
          button.textContent = "실패";
          setTimeout(() => button.textContent = "복사", 1200);
        }
      });
      header.appendChild(button);
    });
  }

  function initUi5ValidationPractice(root) {
    const input = root.querySelector("[data-lab-input]");
    const screenValue = root.querySelector("[data-lab-screen]");
    const modelValueEl = root.querySelector("[data-lab-model]");
    const messagesEl = root.querySelector("[data-lab-messages]");
    const statusEl = root.querySelector("[data-lab-status]");
    const saveBtn = root.querySelector("[data-lab-save]");
    const resetBtn = root.querySelector("[data-lab-reset]");
    const fillButtons = root.querySelectorAll("[data-lab-fill]");

    let modelValue = 20;
    let messages = [];

    function render(statusText, state) {
      screenValue.textContent = input.value === "" ? "(빈 값)" : input.value;
      modelValueEl.textContent = String(modelValue);

      input.classList.remove("error", "success");
      statusEl.classList.remove("error", "success");
      if (state) {
        input.classList.add(state);
        statusEl.classList.add(state);
      }
      statusEl.textContent = statusText;

      if (!messages.length) {
        messagesEl.innerHTML = '<div class="lab-message-item success">메시지 없음 — 저장 Guard 통과 가능</div>';
        return;
      }

      messagesEl.innerHTML = messages.map(function (message) {
        return '<div class="lab-message-item">' +
          '<strong>' + message.type + '</strong><br>' +
          message.message + '<br>' +
          '<small>target: ' + message.target + '</small>' +
          '</div>';
      }).join("");
    }

    function validate() {
      const raw = input.value.trim();
      messages = [];

      if (!/^-?\d+$/.test(raw)) {
        messages.push({
          type: "Error",
          message: "parseError: 숫자로 해석할 수 없습니다.",
          target: "view>/Age"
        });
        render("검증 실패: Input 값은 남지만 Model 값은 " + modelValue + "로 유지됩니다.", "error");
        return;
      }

      const parsed = Number(raw);
      if (parsed < 1 || parsed > 120) {
        messages.push({
          type: "Error",
          message: "validationError: 1부터 120 사이의 값이어야 합니다.",
          target: "view>/Age"
        });
        render("검증 실패: 숫자는 맞지만 constraints를 통과하지 못했습니다. Model 값은 유지됩니다.", "error");
        return;
      }

      modelValue = parsed;
      render("검증 성공: Model 값이 " + modelValue + "로 반영되었습니다.", "success");
    }

    input.addEventListener("input", validate);
    fillButtons.forEach(function (button) {
      button.addEventListener("click", function () {
        input.value = button.getAttribute("data-lab-fill");
        validate();
      });
    });

    saveBtn.addEventListener("click", function () {
      if (messages.some(m => m.type === "Error")) {
        render("저장 Guard 차단: MessageModel에 Error가 있어 저장 로직으로 진행하지 않습니다.", "error");
        return;
      }
      render("저장 Guard 통과: Model 값 " + modelValue + "를 저장 대상으로 사용할 수 있습니다.", "success");
    });

    resetBtn.addEventListener("click", function () {
      modelValue = 20;
      messages = [];
      input.value = "20";
      render("초기화 완료: 현재 Model 값은 20입니다.", "");
    });

    render("아직 오류가 없습니다. 값을 바꾸면 즉시 검증됩니다. 현재 Model 값은 20입니다.", "");
  }

  function initPractices() {
    document.querySelectorAll("[data-practice='ui5-validation']").forEach(initUi5ValidationPractice);
  }

  function initTabs() {
    document.querySelectorAll("[data-tabs]").forEach(function (tabs) {
      const buttons = tabs.querySelectorAll("[data-tab-button]");
      const panels = tabs.querySelectorAll("[data-tab-panel]");
      buttons.forEach(function (button) {
        button.addEventListener("click", function () {
          const target = button.getAttribute("data-tab-button");
          buttons.forEach(b => b.classList.remove("active"));
          panels.forEach(p => p.hidden = p.getAttribute("data-tab-panel") !== target);
          button.classList.add("active");
        });
      });
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    initTerms();
    initCopyButtons();
    initPractices();
    initTabs();
  });
}());
